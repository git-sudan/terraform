###########################################################################
########################### RDS POSTGRES MODULE ###########################
###########################################################################
CREATED BY : Rupali Munjewar & Sudarshan Veerasamy
VERSION     : 1.0 
TERRAFORM VERSION  : >0.12.28
ABOUT :  THIS IS A SHELL DRIVEN AUTOMATED SOLUTION FOR HOSTING RDS INSTANCE ON AWS 
PREREQUSITES : THIS MODULE NEEDS A DEDICATED TERRAFORM MANAGED SUBNET GROUP AND SECURITY GROUP | PLEASE CHECK THE README ON BELOW DIRECTORY FOR HOW TO CREATE
               CREATE SECURITY AND SUBNET GROUP AND CREATE ONE DEDICATED SUBNET AND SECURITY GROUP
	       
###########################################################################

ALL WE NEED TO DO IS call pg-rds.sh, below are the inputs 

SECURITY AND SUBNET GROUP ENTRIES ARE ALREADY MAPPED ON CONFIGURATION FILE

WE CAN CANCEL AND START FROM THE BEGINING IF WE ENTER ANY INPUT INCORRECTLY | CTRL+C to CANCEL


VPCNAME="rdsdbapoc"                     : VPC NAME WHERE RDS INSTANCE TO BE HOSTED
REGION="us-east-2"                      : REGION OF VPC | S3 BUCKET FOR STORING STATE FILE SHOULD BE ON THE SAME REGION
AVAILABILITYZONE="us-east-2a"           : AVAILABLITY ZONE WHERE YOU WANT RDS INSTANCE TO BE HOSTED
APPNAME="wfx"                           : 
CLIENTNAME="chtr"                       : 
ENGINE="postgres"                       : THIS MODULE IS ONLY FOR POSTGRES
ENGINEVERSION="11.8"                    : LIST OF ENGINE VERSIONS WILL BE PROMPTED
LICENSE="postgresql-license"            : DEFAULT ONE
ENVIRONMENT="test"                      : 
DBNAME="wfxchtrtest0006"                : 
UNIQUEID="pg-wfxchtrtest0006"           : 
INSTANCECLASS="db.t3.small"             : 
STORAGETYPE="gp2"                       : GP2 AND IO ARE THE AVAILABLE OPTIONS
ALLOCATEDSTORAGE="20"                   : 
STORAGEENCRYPTION="true"                : 
ADMINUSER="awsadmin"                    : 
ADMINPASSWORD="13941c29d3"              : HARD CODED PASSWORD WILL GETS REPLACED in vars.log file ON NEXT RUN
MULTIAZ="false"                         : 
MAINTENANCEWINDOW="Mon:00:00-Mon:03:00" : 
BACKUPWINDOW="21:00-22:00"              : 
BACKUPRETENTION="2"                     : 
PRODUCTCODE="0800"                      : 
GAMFUNCTION="database"                  : 
GAMSERVICELEVEL="db"                    : 
REMEDYGROUP="DBA-POSTGRES"              : 
CUSTOMER="COMCASR"                      : 
SECURITYCLASS="C"                       : 
