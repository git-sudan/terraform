#!/bin/bash
NONE='\033[00m'
RED='\033[01;31m'
GREEN='\033[01;32m'
WHITE='\033[01;37m'
BOLD='\033[1m'
UNDERLINE='\033[4m'
echo -e "${BOLD}${GREEN}*********************************************${NONE}"
echo -e "${BOLD}${GREEN}         AWS RDS WITH TERRAFORM              ${NONE}"
echo -e "${BOLD}${RED}****THIS IS A ONE TIME STEP FOR YOUR INFRASTRUCTURE*****${NONE}"
echo -e "${BOLD}${GREEN}*********************************************${NONE}"
echo -e " "
echo -e "${BOLD}${RED}ENTER VPC NAME${NONE}"
read VPCNAME
echo "VPCNAME=\"$VPCNAME\"" > vars.log
echo -e " "
echo -e "${BOLD}${RED}ENTER VPC REGION${NONE}"
read REGION
echo "REGION=\"$REGION\"" >> vars.log
cp vars.log ../conf_data/terraform.tfvars
cd ../conf_data
echo -e " "
echo -e "${BOLD}${GREEN}TAKING SUBNET DETAILS FROM AWS${NONE}"
sleep 2
echo -e " "
echo -e "${BOLD}${RED}THIS COULD TAKE FEW MINUTES IF YOU ARE DOING FOR FIRST TIME ${NONE}|${WHITE} PLEASE WAIT TILL IT ASKS FOR INPUT${NONE}"
sleep 9
terraform init > init.log
if [ $? -eq 0 ]; then
echo -e "${BOLD}${GREEN}INITIALIZATION SUCCESS${NONE}"
echo -e " "
else
echo -e "${BOLD}${RED}INITIALIZATION FAILED ${NONE}"
cat init.log
exit 2;
fi
terraform apply > apply.log
if [ $? -eq 0 ]; then
echo -e "${BOLD}${GREEN}APPLY SUCCESS !!${NONE}"
echo -e " "
echo -e "${BOLD}${GREEN}*****************CHECK OUTPUT SECTION BELOW ***********************${NONE}"
echo -e " "
cat apply.log
rm apply.log
echo -e " "
echo -e "${BOLD}${GREEN}*******************************************************************${NONE}"
else
echo -e "${BOLD}${RED}ERROR COLLECTING INFRASTRUCTURE DATA${NONE}"
cat apply.log
rm apply.log
exit 2;
fi
cd ../SG-SUBNET-GROUP/
echo -e " "
echo -e "${BOLD}${RED}ENTER AVAILABILITY ZONE I NAME BELOW | WHERE YOU WANT YOUR DATABASES TO BE HOSTED${NONE}"
echo -e "${BOLD}${WHITE}CHECK OUTPUT REGION FOR THE LIST OF AZ IN YOUR INFRASTRUCTURE${NONE}"
echo " "
echo -e "${BOLD}${RED}PASTE AZ1 BELOW (WITHOUT DOUBLE QUOTES) ${NONE}"
read AZNAME1
echo "$AZNAME1" > ../conf_data/infrastructure_azs.txt
echo " "
echo -e "${BOLD}${RED}ENTER AVAILABILITY ZONE II NAME BELOW | WHERE YOU WANT YOUR DATABASES TO BE HOSTED (SECONDARY OR CLUSTER INSTANCES)${NONE}"
echo -e "${BOLD}${WHITE}CHECK OUTPUT REGION FOR THE LIST OF AZ IN YOUR INFRASTRUCTURE${NONE}"
echo -e " "
echo -e "${BOLD}${RED}PASTE AZ2 BELOW (WITHOUT DOUBLE QUOTES) ${NONE}"
read AZNAME2
echo "$AZNAME2" >> ../conf_data/infrastructure_azs.txt
echo " "
echo -e "${BOLD}${RED}ENTER CIDR SETTINGS OF $AZNAME1 (WITHOUT DOUBLE QUOTES) ${NONE}"
echo -e "${BOLD}${RED}MATCH THE CIDR VALUE WITH $AZNAME1 AVAILABILITY ZONE OUTPUT ${NONE}"
echo -e "${BOLD}${GREEN}Eg. 10.X.0.0/16 | 192.X.X.0/24 | 172.X.X.0/24 ${NONE}"
read CIDR1
echo "CIDR1=[\"$CIDR1\"]" >> vars.log
echo -e " "
echo -e "${BOLD}${RED}ENTER CIDR SETTINGS OF $AZNAME2 (WITHOUT DOUBLE QUOTES) ${NONE}"
echo -e "${BOLD}${RED}MATCH THE CIDR VALUE WITH $AZNAME2 AVAILABILITY ZONE OUTPUT ${NONE}"
echo -e "${BOLD}${GREEN}Eg. 10.X.0.0/16 | 192.X.X.0/24 | 172.X.X.0/24 ${NONE}"
read CIDR2
echo "CIDR2=[\"$CIDR2\"]" >> vars.log
echo -e " "
echo -e "${BOLD}${WHITE}PLEASE BE AWARE SECURITY GROUP csg-rds-standard-sg WILL BE CREATED WHICH ALLOWS TO AND FROM CONNECTIONS ONLY ON PORT 80 FOR IP RANGES ON CIDR - $CIDR1 and $CIDR2 ${NONE}"
echo -e " "
echo -e "${BOLD}${RED}ENTER A SUBNET ID OF AVAILABILITY ZONE I a.k.a PRIMARY AVAILABILITY ZONE | A PRIVATE DATABASE SUBNET${NONE}"
echo " "
echo -e "${BOLD}${RED}PASTE SUBNET ID BELOW (WITHOUT DOUBLE QUOTES) ${NONE}"
read AZ1
echo "AZ1=\"$AZ1\"" >> vars.log
echo " "
echo -e "${BOLD}${WHITE}ENTER A SUBNET ID OF AVAILABILITY ZONE II a.k.a SECONDARY AVAILABILITY ZONE | A PRIVATE DATABASE SUBNET${NONE}"
echo -e " "
echo -e "${BOLD}${RED}PASTE SUBNET ID BELOW (WITHOUT DOUBLE QUOTES) ${NONE}"
read AZ2
echo "AZ2=\"$AZ2\"" >> vars.log
echo -e " "
cp vars.log sub_sec_group.tfvars
if [ $? -eq 0 ]; then
rm vars.log
else
echo -e "${BOLD}${RED}VAR FILE CREATION FAILED | EXIT 2${NONE}"
echo -e "${BOLD}${RED} MAKE OWN VARFILE FROM vars.log${NONE}"
exit 2;
fi
echo -e "${BOLD}${GREEN}CROSSCHECK BELOW DATA | EDIT terraform.tfvars ONLY IF YOU FIND ANY SPACE ISSUE IN VARIABLE ASSIGNMENT${NONE}"
echo -e " "
cat sub_sec_group.tfvars
echo -e " "
echo -e "${BOLD}${GREEN}********************************************************${NONE}"
echo -e "${BOLD}${GREEN}PERFORM BELOW STEPS AFTER VALIDATION:${NONE}"
echo -e "${BOLD}${GREEN}terraform init${NONE}"
echo -e "${BOLD}${GREEN}terraform plan -var-file=sub_sec_group.tfvars${NONE}"
echo -e "${BOLD}${GREEN}terraform apply -var-file=sub_sec_group.tfvars${NONE}"
echo -e "${BOLD}${GREEN}********************************************************${NONE}"
